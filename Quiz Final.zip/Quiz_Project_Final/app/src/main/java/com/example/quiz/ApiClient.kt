package com.example.quiz

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

object ApiClient {
    // Android Emulator -> komputer host. Ganti IP komputer jika memakai HP fisik.
    private const val BASE_URL = "http://192.168.1.11/quiz_api/"

    fun post(endpoint: String, body: JSONObject, callback: (Boolean, JSONObject?, String) -> Unit) {
        Thread {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL(BASE_URL + endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 10000
                    readTimeout = 10000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    setRequestProperty("Accept", "application/json")
                }
                OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val responseText = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
                val json = JSONObject(responseText)
                val success = json.optBoolean("success", false)
                val message = json.optString("message", "Tidak ada pesan dari server")
                callback(success, json, message)
            } catch (e: Exception) {
                callback(false, null, "Tidak dapat terhubung ke server. Periksa Apache/MySQL, alamat API, dan koneksi jaringan.")
            } finally {
                connection?.disconnect()
            }
        }.start()
    }
}

package com.example.quiz

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (getSharedPreferences("quiz_session", MODE_PRIVATE).getBoolean("logged_in", false)) {
            startActivity(Intent(this, DashboardActivity::class.java))
            finish()
            return
        }
        setContentView(R.layout.activity_main)

        val emailInput = findViewById<EditText>(R.id.etEmail)
        val passwordInput = findViewById<EditText>(R.id.etPassword)
        val loginButton = findViewById<Button>(R.id.btnLogin)
        val registerLink = findViewById<TextView>(R.id.tvGoRegister)

        loginButton.setOnClickListener {
            val email = emailInput.text.toString().trim()
            val password = passwordInput.text.toString()
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Email dan password wajib diisi", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            loginButton.isEnabled = false
            val request = JSONObject().put("email", email).put("password", password)
            ApiClient.post("login.php", request) { success, result, message ->
                runOnUiThread {
                    loginButton.isEnabled = true
                    if (success && result != null) {
                        val user = result.optJSONObject("data") ?: JSONObject()
                        getSharedPreferences("quiz_session", MODE_PRIVATE).edit()
                            .putBoolean("logged_in", true)
                            .putInt("user_id", user.optInt("id"))
                            .putString("nama", user.optString("nama"))
                            .putString("email", user.optString("email"))
                            .apply()
                        startActivity(Intent(this, DashboardActivity::class.java))
                        finish()
                    } else Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                }
            }
        }
        registerLink.setOnClickListener { startActivity(Intent(this, RegisterActivity::class.java)) }
    }
}

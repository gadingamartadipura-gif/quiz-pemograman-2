QUIZ — APLIKASI LOGIN DAN REGISTER (KOTLIN + XML + PHP + MYSQL)
==================================================================

ISI PAKET
- Project Android Studio: app/src/main/...
- Splash Screen, Login, Register, Dashboard, Logout
- API client Kotlin menggunakan HTTP POST JSON
- Backend PHP: config.php, register.php, login.php
- Database: backend/database.sql

PENTING
Paket ini adalah source project. APK belum dibangun/dijalankan pada komputer kamu, jadi setelah dibuka di Android Studio lakukan Gradle Sync dan uji sesuai langkah di bawah.

A. BUKA PROJECT ANDROID
1. Ekstrak folder Quiz_Project_Final dari ZIP.
2. Android Studio > File > Open.
3. Pilih folder Quiz_Project_Final (folder yang berisi settings.gradle dan build.gradle), bukan folder app.
4. Tunggu Gradle Sync. Project disetel untuk Android Studio Bumblebee: Android Gradle Plugin 7.1.3, Gradle 7.2, Kotlin 1.6.10, compile SDK 31, minimum SDK 25.
5. Jika diminta memasang Android SDK Platform 31, izinkan pemasangan. Jika jaringan tidak tersedia, Sync mungkin gagal sampai dependensi dapat diunduh.
6. Buat/jalankan emulator Android API 25 atau lebih baru, lalu tekan Run.

B. SIAPKAN BACKEND XAMPP
1. Jalankan Apache dan MySQL di XAMPP Control Panel.
2. Buka http://localhost/phpmyadmin.
3. Pilih tab Import dan pilih file backend/database.sql, atau buka tab SQL lalu salin isi file itu.
4. Salin folder backend ke C:\xampp\htdocs\quiz_api\ sehingga file berikut ada:
   C:\xampp\htdocs\quiz_api\config.php
   C:\xampp\htdocs\quiz_api\register.php
   C:\xampp\htdocs\quiz_api\login.php
5. Konfigurasi default config.php adalah MySQL localhost, username root, password kosong, database quiz. Sesuaikan jika instalasi kamu berbeda.
6. Buka http://localhost/quiz_api/login.php di browser komputer. Untuk GET, respons "Gunakan metode POST" adalah normal karena endpoint menerima POST.

C. ALAMAT API
- Android Emulator di komputer yang sama: http://10.0.2.2/quiz_api/
- HP fisik: ubah BASE_URL di ApiClient.kt menjadi http://ALAMAT-IP-KOMPUTER/quiz_api/ dan pastikan HP serta komputer berada pada jaringan yang sama serta firewall mengizinkan koneksi Apache.
- HTTP cleartext diaktifkan hanya untuk pengujian lokal. Untuk aplikasi produksi, gunakan HTTPS.

D. UJI FITUR
1. Pastikan Apache dan MySQL aktif.
2. Jalankan aplikasi di emulator.
3. Tekan Daftar, isi nama, email valid, password minimal 8 karakter, dan konfirmasi password yang sama.
4. Pastikan muncul Registrasi berhasil.
5. Di phpMyAdmin, buka quiz > users; password seharusnya tersimpan sebagai hash.
6. Kembali ke Login dan masuk dengan email/password tadi.
7. Pastikan Dashboard menunjukkan nama, email, dan ID pengguna.
8. Tekan Logout; aplikasi kembali ke Login.

E. CATATAN TROUBLESHOOTING
- Jika Gradle Sync gagal: pastikan internet tersedia, SDK Platform 31 terpasang, dan JDK yang dipakai Android Studio adalah Embedded JDK.
- Jika tidak bisa terhubung: cek Apache, BASE_URL, dan bahwa endpoint berada di htdocs/quiz_api.
- Jika koneksi database gagal: cek MySQL berjalan, database sudah diimpor, dan kredensial config.php benar.
- Jika build gagal: buka Build Output dan periksa error pertama; jangan hanya melihat error paling bawah.
- Aplikasi menyimpan status login secara lokal di SharedPreferences untuk tugas dasar ini. Backend PDF belum memakai token sesi server; jangan gunakan pendekatan demo ini sebagai autentikasi aplikasi produksi.

F. FILE UTAMA
app/src/main/java/com/example/quiz/SplashActivity.kt
app/src/main/java/com/example/quiz/MainActivity.kt
app/src/main/java/com/example/quiz/RegisterActivity.kt
app/src/main/java/com/example/quiz/DashboardActivity.kt
app/src/main/java/com/example/quiz/ApiClient.kt
app/src/main/res/layout/activity_splash.xml
app/src/main/res/layout/activity_main.xml
app/src/main/res/layout/activity_register.xml
app/src/main/res/layout/activity_dashboard.xml
app/src/main/AndroidManifest.xml
backend/database.sql, config.php, register.php, login.php


FITUR TAMBAHAN
- CategoryActivity: kategori mata kuliah.
- QuizActivity: contoh kuis pilihan ganda dengan 3 soal latihan.
- ResultActivity: hasil dan nilai latihan.
- HistoryActivity: ringkasan skor terakhir tersimpan lokal.
- ProfileActivity: profil pengguna dan logout.
Catatan: riwayat kuis saat ini tersimpan lokal di perangkat; bukan ke server PHP. Soal kuis adalah contoh latihan dan belum diambil dari database.
